<?php

return [
    'auth_user'=>'mfa@ng_api_user',
    'auth_password'=>'mfa@ng_api_pwd',
    'api_secret_key'=>'1UN2N2P7b5lVQbb6bWEYAwxc+BwMmduIVXGECZSsM=',
    'success_flag' => 200, //return success
    'data_missing' => 400, //The request could not be understood by the server due to malformed syntax. The client SHOULD NOT repeat the request without modifications.
    'api_key_missing' => 401, //api_key missing, NotAuthorized, InvalidApiKey, InsecureConnection
    'invalid_data' => 402, //invalid api key, incorrect username password
    'forbidden_access' => 403, //forbidden access even if user is authenticated
    'not_found' => 404, // resource not found InvalidPath, ObjectNotFound, invalid http method used
    'method_not_allowed' => 405, // resource not found
    'failure_flag' => 500, //something went wrong ,db or quesry error InternalServerException
    'WS_PAGING_LIMIT' => 5, //Pagination limit
    'max_upload_image'=> 5 // max file upload size
];