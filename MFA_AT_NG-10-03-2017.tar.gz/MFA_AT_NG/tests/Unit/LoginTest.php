<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;
//use Illuminate\Foundation\Testing\WithoutMiddleware;

class LoginTest extends TestCase
{
     //use WithoutMiddleware;
    /**
     * A basic test example.
     *
     * @return void
     */
    
     
    public function testExample()
    {
        /*        
        $this->visit('/login')
                    ->type('email', 'admin@admin.com')
                    ->type('password', '123456')
                    ->press('Sign In')
                    ->assertPathIs('/home');
        
        $response = $this->json('GET', '/api/get-countries');
        */
        /*$response
            ->assertStatus(200);*/
        
        //dd($response);
        $this->assertTrue(true);
    }
}
