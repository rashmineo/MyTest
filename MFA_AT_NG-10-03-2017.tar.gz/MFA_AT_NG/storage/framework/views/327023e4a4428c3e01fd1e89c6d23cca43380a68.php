<div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
    <?php echo Form::label('title', 'Title', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('title', array('MR' => 'Mr','MISS'=>'Miss','MRS'=>'Mrs'),null,['class' => 'form-control']);; ?>

        <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
    <?php echo Form::label('first_name', 'First Name', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('first_name', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('first_name', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
    <?php echo Form::label('last_name', 'Last Name', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('last_name', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('last_name', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('gender') ? 'has-error' : ''); ?>">
    <?php echo Form::label('gender', 'Gender', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('gender', ['Male'=>'Male','Female'=>'Female'], null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('gender', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('dob') ? 'has-error' : ''); ?>">
    <?php echo Form::label('dob', 'DOB', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('dob', null, ['placeholder'=>'YYYY-MM-DD','class' => 'form-control']); ?>

        <?php echo $errors->first('dob', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
    <?php echo Form::label('email', 'Email', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('phone_no') ? 'has-error' : ''); ?>">
    <?php echo Form::label('phone_no', 'Phone Number', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('phone_no', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('phone_no', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('country_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('country_id', 'Country', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
       <?php echo Form::select('country_id',  $countries, null, ['class' => 'form-control countries','id'=>"country_id"]); ?>


        <?php echo $errors->first('country_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('state_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('state_id', 'State', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('state_id', $states, null, ['class' => 'form-control states','id'=>"state_id"]); ?>


        <?php echo $errors->first('state_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('city_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('city_id', 'City', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('city_id',  $cities, null, ['class' => 'form-control cities','id'=>"city_id"]); ?>


        <?php echo $errors->first('city_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div>


<div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
    <?php echo Form::label('address', 'Address', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::textarea('address', null, ['class' => 'form-control','rows'=>5]); ?>

        <?php echo $errors->first('address', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('nationality') ? 'has-error' : ''); ?>">
    <?php echo Form::label('nationality', 'Nationality', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('nationality', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('nationality', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<?php if(isset($pageType) && $pageType!='edit'): ?>
<div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
    <?php echo Form::label('password', 'Password', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::password('password', ['class' => 'form-control']); ?>

        <?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('confirm_password') ? 'has-error' : ''); ?>">
    <?php echo Form::label('confirm_password', 'Confirm Password', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::password('confirm_password', ['class' => 'form-control']); ?>

        <?php echo $errors->first('confirm_password', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<?php endif; ?>
<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
<script type="text/javascript">
    
    function ajaxCall() {
        this.send = function(data, url, method, success, type) {
          type = type||'json';
          var successRes = function(data) {
              success(data);
          };

          var errorRes = function(e) {
              console.log(e);
              alert("Error found \nError Code: "+e.status+" \nError Message: "+e.statusText);
          };
            $.ajax({
                url: url,
                type: method,
                data: data,
                success: successRes,
                error: errorRes,
                dataType: type,
                timeout: 60000
            });

          }

        }

function locationInfo() {
    var rootUrl = "";
    var call = new ajaxCall();
    var csrf_token = window.Laravel.csrfToken;
    
    this.getCities = function(id) {
        
        $(".cities option:gt(0)").remove();
        var url = '<?php echo e(url("get-cities")); ?>';
        var method = "post";
        var csrf_token = window.Laravel.csrfToken;
        var data = {'state_id':id,'_token':csrf_token};
        $('.cities').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.cities').find("option:eq(0)").html("Select City");
            if(data.tp == 1){
                $.each(data['result'], function(key, val) {
                    var option = $('<option />');
                    option.attr('value', key).text(val);
                    $('.cities').append(option);
                });
                $(".cities").prop("disabled",false);
            }
            else{
                 alert(data.msg);
            }
        });
    };

    this.getStates = function(id) {
        
        $(".states option:gt(0)").remove(); 
        $(".cities option:gt(0)").remove(); 
        //var url = rootUrl+'?type=getStates&countryId=' + id;
        var url = '<?php echo e(url("get-states")); ?>';
        var method = "post";
        var csrf_token = window.Laravel.csrfToken;
        var data = {'country_id':id,'_token':csrf_token};
        $('.states').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.states').find("option:eq(0)").html("Select State");
            if(data.tp == 1){
                $.each(data['result'], function(key, val) {
                    var option = $('<option />');
                    option.attr('value', key).text(val);
                    $('.states').append(option);
                });
                $(".states").prop("disabled",false);
            }
            else{
                alert(data.msg);
            }
        }); 
    };

    this.getCountries = function() {
        var url = '<?php echo e(url("get-countries")); ?>';
        var method = "post";
        var csrf_token = window.Laravel.csrfToken;
        var data = {'_token':csrf_token};
        
        $('.countries').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.countries').find("option:eq(0)").html("Select Country");
            console.log(data);
            if(data.tp == 1){
                $.each(data['result'], function(key, val) {
                    
                    var option = $('<option />');
                    option.attr('value', key).text(val);
                    $('.countries').append(option);
                });
                $(".countries").prop("disabled",false);
            }
            else{
                alert(data.msg);
            }
        }); 
    };

}

$(function() {
var loc = new locationInfo();
loc.getCountries();
 $(".countries").on("change", function(ev) {
        var countryId = $(this).val();
        if(countryId != ''){
        loc.getStates(countryId);
        }
        else{
            $(".states option:gt(0)").remove();
        }
    });
 $(".states").on("change", function(ev) {
        var stateId = $(this).val();
        if(stateId != ''){
        loc.getCities(stateId);
        }
        else{
            $(".cities option:gt(0)").remove();
        }
    });
});

</script>

