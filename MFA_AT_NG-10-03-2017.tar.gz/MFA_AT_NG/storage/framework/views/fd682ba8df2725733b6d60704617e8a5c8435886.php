<?php $__env->startSection('title','Manage Travel Notices'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Edit Travel Notices</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="panel panel-default">
        <div class="panel panel-heading"><strong>Edit Manage Travel Notices</strong></div>
        <div class="panel panel-body">
            <a href="<?php echo e(url('/travel-notices')); ?>" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left"></i> Back</button></a>            
            <?php echo Form::open(['method'=>'DELETE','url'=> ['/travel-notices/'.$travelNotice->id],'style' => 'display:inline']); ?>                                                
                <?php echo Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i> Delete',[
                    'type'=>'submit',
                    'class'=>'btn btn-danger btn-xs',
                    'title'=>'Delete Travel Notice',
                    'onclick' => 'return confirm("Confirm delete?")'
                ]); ?>

            <?php echo Form::close(); ?>

            
            <br/>
            <br/>
            <div class="col-md-10">
                <div class="edit-form">
                    
                    <?php echo Form::model($travelNotice, [
                            'method' => 'PATCH',
                            'url' => ['/travel-notices', $travelNotice->id],
                            'class' => 'form-horizontal',
                            'files' => true
                        ]); ?>


                        <?php echo $__env->make('travel_notices.form', ['submitButtonText' => 'Update'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <?php echo Form::hidden('status',$travelNotice->status); ?>

                        
                        <?php echo Form::close(); ?>

                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>