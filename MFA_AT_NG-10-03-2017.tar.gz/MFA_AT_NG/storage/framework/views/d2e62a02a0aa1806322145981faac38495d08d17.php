<div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
    <?php echo Form::label('title', 'Title', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
    <?php echo Form::label('description', 'Description', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('description', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::reset(isset($cancelButtonText) ? $cancelButtonText : 'Cancel', ['class' => 'btn btn-danger','title'=>'Cancel']); ?>

        <span>&nbsp;&nbsp;</span>
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Save', ['class' => 'btn btn-primary','title'=>'Save']); ?>

    </div>
</div>
