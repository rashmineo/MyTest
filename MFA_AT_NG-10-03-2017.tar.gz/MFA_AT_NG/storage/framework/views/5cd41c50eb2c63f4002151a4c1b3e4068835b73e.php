<?php $__env->startSection('title', 'Members'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Member</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Member <?php echo e($member->id); ?></div>
                    <div class="panel-body">

                        <a href="<?php echo e(url('/members')); ?>" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <a href="<?php echo e(url('/members/' . $member->id . '/edit')); ?>" title="Edit Member"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['members', $member->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i> Delete', array(
                                    'type' => 'submit',
                                    'class' => 'btn btn-danger btn-xs',
                                    'title' => 'Delete Member',
                                    'onclick'=>'return confirm("Confirm delete?")'
                            )); ?>

                        <?php echo Form::close(); ?>

                        <br/>
                        <br/>

                        <div class="table-responsive">
                            <table class="table table-borderless">
                                <tbody>
                                    <tr><th> Title </th><td> <?php echo e($member->title); ?> </td></tr>
                                    <tr><th> Name </th><td> <?php echo e($member->name); ?> </td></tr>
                                    <tr><th> Email </th><td> <?php echo e($member->email); ?> </td></tr>
                                    <tr><th> Gender </th><td> <?php echo e($member->gender); ?> </td></tr>
                                    <tr><th> DOB </th><td> <?php echo e($member->dob); ?> </td></tr>
                                    <tr><th> Address </th><td> <?php echo e($member->address); ?> </td></tr>
                                    <tr><th> Country </th><td> <?php echo e($member->country->name); ?> </td></tr>
                                    <tr><th> State </th><td> <?php echo e($member->state->name); ?> </td></tr>
                                    <tr><th> City </th><td> <?php echo e($member->city->name); ?> </td></tr>
                                    <tr><th> Phone No </th><td> <?php echo e($member->phone_no); ?> </td></tr>
                                    <tr><th> Nationality </th><td> <?php echo e($member->nationality); ?> </td></tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>