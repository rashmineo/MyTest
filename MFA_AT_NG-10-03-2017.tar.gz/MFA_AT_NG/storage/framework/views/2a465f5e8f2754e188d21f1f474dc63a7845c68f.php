<div class="col-md-offset-2 col-md-6">
<?php if($message = Session::get('success')): ?>
    <div class="alert alert-info">
            <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
</div>
<div class="clearfix"></div>
