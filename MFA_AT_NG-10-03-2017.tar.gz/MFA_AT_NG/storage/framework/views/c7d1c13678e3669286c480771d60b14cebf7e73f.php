<?php $__env->startSection('title', 'Manage Members'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Manage Members</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Members</div>
                    <div class="panel-body">
                        <a href="<?php echo e(url('/members/create')); ?>" class="btn btn-success btn-sm" title="Add New Blog">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New
                        </a>
                        <!--
                        <?php echo Form::open(['method' => 'GET', 'url' => '/members', 'class' => 'navbar-form navbar-right', 'role' => 'search']); ?>

                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <?php echo Form::close(); ?>

                        -->
                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <?php echo $dataTable->table(); ?>                            
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php echo $dataTable->scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>