<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Yajra\Datatables\Datatables;
use App\DataTables\MembersDataTable;
use App\Member;
use App\Country;
use App\State;
use App\City;

class MembersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(MembersDataTable $dataTable)
    {
        return $dataTable->render('members.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $countries = Country::pluck('name','id')->toArray();
        $states = [''=>'Select state'];
        $cities = [''=>'Select city'];
        return view('members.create',compact('countries','states','cities'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->request->set('user_role_id',2); //default user_role_id is 2 for member
        $request->request->set('is_active',true); //default is_active is 1 for active user
        
        $this->validate($request,[
                                    'user_role_id'=>'bail|required|numeric|exists:user_roles,id',
                                    'title'=>'bail|required|in:MR,MISS,MRS',
                                    'first_name'=>'bail|required|alpha_dash|between:1,128',
                                    'last_name'=>'bail|required|alpha_dash|between:1,128',
                                    'gender'=>'bail|required|in:Male,Female',
                                    'dob'=>'bail|required|date|date_format:Y-m-d|before:now|after:-100 years',
                                    'address'=>'bail|required|min:3|max:512',
                                    'country_id'=>'bail|required|numeric|exists:countries,id',
                                    'state_id'=>'bail|required|numeric|exists:states,id',
                                    'city_id'=>'bail|required|numeric|exists:cities,id',
                                    'email'=>'bail|required|between:5,64|email|unique:users',                                
                                    'password'=>'bail|required|min:6|max:32',
                                    'confirm_password'=>'required|min:6|same:password',
                                    'phone_no'=>'bail|required|min:10|numeric',
                                    'nationality'=>'bail|required|alpha_dash|min:2',
                                    'is_active'=>'bail|required|boolean',                                
                            ],[
                                    'title.in'=>'The selected title is in MR, MISS Or MRS list',
                                    'gender.in'=>'The selected gender is in Male, Female list',
                            ]);            
            
            $name = $request->input('first_name').' '.$request->input('last_name');
            $request->request->set('name',$name); //set name field
        
            Member::create($request->all());
            
            return redirect()->route('members.index')->with('success','Member added successfully.');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $member = Member::find($id);
        return view('members.show',compact('member'));        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $member = Member::find($id);
        $countries = Country::pluck('name','id')->toArray();
        $states = State::where('country_id',$member->country_id)->pluck('name','id')->toArray();
        $cities = City::where('state_id',$member->state_id)->pluck('name','id')->toArray();
        return view('members.edit',compact('member','countries','states','cities'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->request->set('user_role_id',2); //default user_role_id is 2 for member
        $request->request->set('is_active',true); //default is_active is 1 for active user
        
        $this->validate($request,[
                                    'user_role_id'=>'bail|required|numeric|exists:user_roles,id',
                                    'title'=>'bail|required|in:MR,MISS,MRS',
                                    'first_name'=>'bail|required|alpha_dash|between:1,128',
                                    'last_name'=>'bail|required|alpha_dash|between:1,128',
                                    'gender'=>'bail|required|in:Male,Female',
                                    'dob'=>'bail|required|date|date_format:Y-m-d|before:now|after:-100 years',
                                    'address'=>'bail|required|min:3|max:512',
                                    'country_id'=>'bail|required|numeric|exists:countries,id',
                                    'state_id'=>'bail|required|numeric|exists:states,id',
                                    'city_id'=>'bail|required|numeric|exists:cities,id',
                                    'email'=>'bail|required|between:5,64|email|unique:users,email,'.$id,                                
                                    'phone_no'=>'bail|required|min:10|numeric',
                                    'nationality'=>'bail|required|alpha_dash|min:2',
                                    'is_active'=>'bail|required|boolean',                                
                            ],[
                                    'title.in'=>'The selected title is in MR, MISS Or MRS list',
                                    'gender.in'=>'The selected gender is in Male, Female list',
                            ]);            
            
            $name = $request->input('first_name').' '.$request->input('last_name');
            $request->request->set('name',$name); //set name field
            
            Member::find($id)->update($request->all());
            
            return redirect()->route('members.index')->with('success','Member updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
