<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\TravelNotice;
use Auth;

class TravelNoticiesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $keyword = $request->get('search');
        $perPage = 5;
        $conditions = array();
        
        if(!empty($keyword)){
            $travelNoticies = TravelNotice::where('title', 'LIKE', "%$keyword%")
                                ->orWhere('description', 'LIKE', "%$keyword%")
                                ->orderBy('id','DESC')->paginate($perPage);
        }else{        
            $travelNoticies = TravelNotice::orderBy('id','DESC')->paginate($perPage);
        }
        //dd($travelNoticies->toArray());
        
        return view('travel_notices.index',['travelNoticies'=>$travelNoticies])
                ->with('i',($request->input('page',1)-1)*5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         
        $request->request->set('status',1); //default status is 1
        
        $this->validate($request,[
            'title'=>'bail|required|min:3|max:255',
            'description'=>'bail|required|min:3',
            'status'=>'required',
        ]);
        
        TravelNotice::create($request->all());
        
        return redirect()->route('travel-notices.index')->with('success','Travel Notice has been saved.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $travelNotice = TravelNotice::find($id);
        return view('travel_notices.view',compact('travelNotice'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $travelNotice = TravelNotice::find($id);
        return view('travel_notices.edit',compact('travelNotice'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'title'=>'bail|required|min:3|max:255',
            'description'=>'bail|required|min:3',
            'status'=>'required',
        ]);
        
        TravelNotice::find($id)->update($request->all());
        
        return redirect()->route('travel-notices.index')->with('success','Travel Notice has been updated.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        TravelNotice::find($id)->delete();
        return redirect()->route('travel-notices.index')->with('success','Travel Notice has been deleted.');
    }
    
    /**
     * Change the specified resource status.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function status(Request $request){
        
        $this->validate($request,[
            'id'=>'bail|required',
            'status'=>'required',
        ]);        
        
        TravelNotice::find($request->input('id'))->update(['status'=>$request->input('status')]);
        
        return redirect()->route('travel-notices.index')->with('success','Travel Notcie status has been changed.');
    }
}
