<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Country;
use App\State;
use App\City;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;

class LocationsController extends Controller
{
    
    /*
     * function name : getCountries Web Service
     * Web Service for getting list of countries
     * @author :  Chandrakant Ganji
     * @access : public
     * @param : Request $request object
     * @return : JSON Response with HTTP Header
     */
    
    /**
     * @api {get} http://mfa-at-ng.com/api/get-countries  Country List
     * @apiName Country List
     * @apiGroup Locations
     * @apiDescription
     * This api for getting list of countries
     *
     * @apiVersion 1.0.0
     * @apiHeader {String} Apikey  User access token { header }
     * @apiHeader {String} username  Api access username { header }
     * @apiHeader {String} password  Api access password { header }
     * 
     * @apiSampleRequest http://mfa-at-ng.com/api/get-countries
     *
     * @apiSuccess {Boolean} status true
     * @apiSuccess {Integer} status_code Status code, 200 for success
     * @apiSuccess {Object} result Data object
     * @apiSuccess {String} message message to user
     *
     * @apiSuccessExample Success-Response:
     *      HTTP/1.1 200 Ok.
     *        {
     *          "status": true,
     *           "status_code": 200,
     *           "message": "Countries fetched successfully.",
     *           "result": {
     *             "1": "Afghanistan",
     *             "2": "Albania",
     *             "3": "Algeria",
     *             "4": "American Samoa",
     *             "5": "Andorra",
     *             "6": "Angola",
     *             "7": "Anguilla",
     *             "8": "Antarctica",
     *             "9": "Antigua And Barbuda",
     *             "10": "Argentina",
     *             "11": "Armenia",
     *             ...
     *          }
     *        }
     *
     *
     * @apiError WrongMethod request method must be GET
     * @apiErrorExample Error-Response: Wrong method
     *     HTTP/1.1 403 Forbidden.
     *      {
     *         "status": false,
     *         "result": {},
     *         "message": "Wrong request method, must be GET"
     *      }
     */
    
    public function getCountries(Request $request){
        $success_flag = config('constants.success_flag');
        $invalid_data = config('constants.invalid_data');        
        $data_missing = config('constants.data_missing');        
        $response_code = config('constants.success_flag');
        
        $countries = Country::orderBy('name','asc')->pluck('name','id')->toArray();
        if(count($countries)>0){
            $data = array('status'=>true, 'status_code'=>$success_flag, 'message'=>"Countries fetched successfully.", 'result'=>$countries);
        }else{
            $response_code=$invalid_data;
            $data = array('status'=>false, 'status_code'=>$invalid_data, 'message'=>'Country list not exists');
        }
        
        return response($data,$response_code);
    }
    
    /*
     * function name : getStates Web Service
     * Web Service for getting list of states of country by country id
     * @author :  Chandrakant Ganji
     * @access : public
     * @param : Request $request object
     * @return : JSON Response with HTTP Header
     */
    
    /**
     * @api {post} http://mfa-at-ng.com/api/get-states  State List
     * @apiName State List
     * @apiGroup Locations
     * @apiDescription
     * This api for getting list of states of country by country id
     *
     * @apiVersion 1.0.0
     * @apiHeader {String} Apikey  User access token { header }
     * @apiHeader {String} username  Api access username { header }
     * @apiHeader {String} password  Api access password { header }
     * 
     * @apiSampleRequest http://mfa-at-ng.com/api/get-states
     *
     * @apiParam {Number} country_id location country_id is required
     * 
     * @apiSuccess {Boolean} status true
     * @apiSuccess {Integer} status_code Status code, 200 for success
     * @apiSuccess {Object} result Data object
     * @apiSuccess {String} message message to user
     *
     * @apiSuccessExample Success-Response:
     *      HTTP/1.1 200 Ok.
     *        {
     *          "status": true,
     *           "status_code": 200,
     *           "message": "States fetched successfully.",
     *           "result": {
     *                       "1": "Andaman and Nicobar Islands",
     *                       "2": "Andhra Pradesh",
     *                       "3": "Arunachal Pradesh",
     *                       "4": "Assam",
     *                       "5": "Bihar",
     *                       "6": "Chandigarh",
     *                       "7": "Chhattisgarh",
     *                       "8": "Dadra and Nagar Haveli",
     *                       "9": "Daman and Diu",
     *                       "10": "Delhi",
     *                       "11": "Goa",
     *                       "12": "Gujarat",
     *                       "13": "Haryana",
     *                      ...
     *              }
     *        }
     *
     *
     * @apiError WrongMethod request method must be POST
     * @apiErrorExample Error-Response: Wrong method
     *     HTTP/1.1 403 Forbidden.
     *      {
     *         "status": false,
     *         "result": {},
     *         "message": "Wrong request method, must be POST"
     *      }
     */
    
    public function getStates(Request $request){                
        $success_flag = config('constants.success_flag');
        $invalid_data = config('constants.invalid_data');        
        $data_missing = config('constants.data_missing');      
        $response_code = config('constants.success_flag');
        
        $validator = Validator::make($request->all(),['country_id'=>'required']);
                
        if (!$validator->fails()){
            $states = State::where('country_id',$request->input('country_id'))->orderBy('name','asc')->pluck('name','id')->toArray();
            if(count($states)>0){
                $data = array('status'=>true, 'status_code'=>$success_flag, 'message'=>"States fetched successfully.", 'result'=>$states);
            }else{
                $response_code=$data_missing;
                $data = array('status'=>false,'status_code'=>$data_missing,  'message'=>'States list not exists');
            }
        }else{
            $response_code=$invalid_data;
            $data = array('status'=>false,'status_code'=>$invalid_data, 'result'=>[], 'message'=>$validator->messages());
        }
        
        return response($data,$response_code);
    }


    /*
     * function name : getCities Web Service
     * Web Service for getting list of cities of state by state id
     * @author :  Chandrakant Ganji
     * @access : public
     * @param : Request $request object
     * @return : JSON Response with HTTP Header
     */
    
    /**
     * @api {post} http://mfa-at-ng.com/api/get-cities  City List
     * @apiName City List
     * @apiGroup Locations
     * @apiDescription
     * This api for getting list of cities of state by state id
     *
     * @apiVersion 1.0.0
     * @apiHeader {String} Apikey  User access token { header }
     * @apiHeader {String} username  Api access username { header }
     * @apiHeader {String} password  Api access password { header }
     * 
     * @apiSampleRequest http://mfa-at-ng.com/api/get-cities
     *
     * @apiParam {Number} state_id location state_id is required
     * 
     * @apiSuccess {Boolean} status true
     * @apiSuccess {Integer} status_code Status code, 200 for success
     * @apiSuccess {Object} result Data object
     * @apiSuccess {String} message message to user
     *
     * @apiSuccessExample Success-Response:
     *      HTTP/1.1 200 Ok.
     *        {
     *          "status": true,
     *           "status_code": 200,
     *           "message": "Cities fetched successfully.",
     *           "result": {
     *                       "2475": "Aheri",
     *                       "2476": "Ahmadnagar Cantonment",
     *                       "2477": "Ahmadpur",
     *                       "2478": "Ahmednagar",
     *                       "2479": "Ajra",
     *                       "2480": "Akalkot",
     *                       "2481": "Akkalkuwa",
     *                       "2482": "Akola",
     *                       "2483": "Akot",
     *                       "2484": "Alandi",
     *                       "2485": "Alibag",
     *                       "2486": "Allapalli",
     *                       "2487": "Alore",
     *                       "2488": "Amalner",
     *                       "2489": "Ambad",
     *                       "2490": "Ambajogai",
     *                       "2491": "Ambernath",
     *                       "2492": "Ambivali Tarf Wankhal",
     *                       "2493": "Amgaon",
     *                       "2494": "Amravati",
     *                      ...
     *              }
     *        }
     *
     *
     * @apiError WrongMethod request method must be POST
     * @apiErrorExample Error-Response: Wrong method
     *     HTTP/1.1 403 Forbidden.
     *      {
     *         "status": false,
     *         "result": {},
     *         "message": "Wrong request method, must be POST"
     *      }
     */
    
    public function getCities(Request $request){
        $success_flag = config('constants.success_flag');
        $invalid_data = config('constants.invalid_data');      
        $data_missing = config('constants.data_missing');        
        
        $validator = Validator::make($request->all(),['state_id'=>'required']);
                
        if (!$validator->fails()){
        
            $cities = City::where('state_id',$request->input('state_id'))->orderBy('name','asc')->pluck('name','id')->toArray();
            if(count($cities)>0){
                $data = array('status'=>true,'status_code'=>$success_flag,  'message'=>"Cities fetched successfully.", 'result'=>$cities);
            }else{
                $data = array('status'=>false,'status_code'=>$data_missing,  'message'=>'Cities list not exists');
            }
        
        }else{
            $data = array('status'=>false,'status_code'=>$invalid_data, 'result'=>[], 'message'=>$validator->messages());
        }
        
        return response($data,201);
    }
}
