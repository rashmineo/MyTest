<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\GroupDetails;

class GroupDetailsController extends Controller
{
    /*
     * function name : Add Group Web Service
     * Web Service for add member group
     * @author :  Chandrakant Ganji
     * @access : public
     * @param : Request $request object
     * @return : JSON Response with HTTP Header
     */
    
    public function add(Request $request){
        //Add Group
    }
}
