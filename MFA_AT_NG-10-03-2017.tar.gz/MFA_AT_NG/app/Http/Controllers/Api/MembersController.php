<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Member;
use App\Traits\AuthorizesApiRequests;

class MembersController extends Controller
{

    use AuthorizesApiRequests;
    /*
     * function name : register Web Service
     * Web Service for member register
     * @author :  Chandrakant Ganji
     * @access : public
     * @param : Request $request object
     * @return : JSON Response with HTTP Header
     */
    
    /**
     * @api {post} http://mfa-at-ng.com/api/members/register  Register
     * @apiName Register
     * @apiGroup Member
     * @apiDescription
     * This api for member registration
     *
     * @apiVersion 1.0.0
     * @apiHeader {String} Apikey  User access token { header }
     * @apiHeader {String} username  Api access username { header }
     * @apiHeader {String} password  Api access password { header }
     * 
     * @apiSampleRequest http://mfa-at-ng.com/api/members/register
     *
     * @apiParam {String} title member title is required , title in [MR, MISS Or MRS]
     * @apiParam {String} first_name member first_name is required
     * @apiParam {String} last_name member last_name is required
     * @apiParam {String} gender member gender is required value enum('Male', 'Female')
     * @apiParam {Date} dob member dob is required of format YYYY-MM-DD
     * @apiParam {String} address member address is required
     * @apiParam {Number} country_id member country_id is required
     * @apiParam {Number} state_id member state_id is required
     * @apiParam {Number} city_id member city_id is required
     * @apiParam {String} email member email is required
     * @apiParam {String} password member password is required
     * @apiParam {Number} phone_no member phone_no is required
     * @apiParam {String} nationality member nationality is required
     *
     * @apiSuccess {Boolean} status true
     * @apiSuccess {Integer} status_code Status code, 200 for success
     * @apiSuccess {Object} result Data object
     * @apiSuccess {String} message message to user
     *
     * @apiSuccessExample Success-Response:
     *      HTTP/1.1 200 Ok.
     *        {
     *           "status": true,
     *           "status_code": 200,
     *           "message": "Registration successfully.",
     *           "result": {
     *                       "id": 10,
     *                       "title": "MR",
     *                       "name": "Ratan Ganure",
     *                       "first_name": "Ratan",
     *                       "last_name": "Ganure",
     *                       "gender": "Male",
     *                       "dob": "1990-05-05",
     *                       "address": "Dadar",
     *                       "country_id": 101,
     *                       "state_id": 22,
     *                       "city_id": 2707,
     *                       "email": "ratan@gmail.com",
     *                       "phone_no": "9546454813",
     *                       "nationality": "Indian",
     *                       "auth_token": "D95zT6lEzTxTlQgC2tJKTBUtLphGbE01rVDYDGSEjqa4DQs9DbwuRsVyAMVFUlpn",
     *                       "country": {
     *                         "id": 101,
     *                         "sortname": "IN",
     *                         "name": "India",
     *                         "phonecode": 91
     *                       },
     *                       "state": {
     *                         "id": 22,
     *                         "name": "Maharashtra",
     *                         "country_id": 101
     *                       },
     *                       "city": {
     *                         "id": 2707,
     *                         "name": "Mumbai",
     *                         "state_id": 22
     *                       }
     *               }
     *        }
     *
     *
     * @apiError WrongMethod request method must be POST
     * @apiErrorExample Error-Response: Wrong method
     *     HTTP/1.1 403 Forbidden.
     *      {
     *         "status": false,
     *         "result": {},
     *         "message": "Wrong request method, must be POST"
     *      }
     */

    public function register(Request $request){
        
        $success_flag = config('constants.success_flag');
        $invalid_data = config('constants.invalid_data');        
        $data_missing = config('constants.data_missing');        
        $failure_flag = config('constants.failure_flag');        
        $forbidden_access = config('constants.forbidden_access');        
        $response_code = config('constants.success_flag');
        
        $request->request->set('user_role_id',2); //default user_role_id is 2 for member
        $request->request->set('is_active',true); //default is_active is 1 for active user
        $request->request->set('auth_token',str_random(64)); //default is_active is 1 for active user
        
        $validator = \Validator::make($request->all(),
                            [
                                'user_role_id'=>'bail|required|numeric|exists:user_roles,id',
                                'title'=>'bail|required|in:MR,MISS,MRS',
                                'first_name'=>'bail|required|alpha_dash|between:1,128',
                                'last_name'=>'bail|required|alpha_dash|between:1,128',
                                'gender'=>'bail|required|in:Male,Female',
                                'dob'=>'bail|required|date|date_format:Y-m-d|before:now|after:-100 years',
                                'address'=>'bail|required|min:3|max:512',
                                'country_id'=>'bail|required|numeric|exists:countries,id',
                                'state_id'=>'bail|required|numeric|exists:states,id',
                                'city_id'=>'bail|required|numeric|exists:cities,id',
                                'email'=>'bail|required|between:5,64|email|unique:users',                                
                                //'username'=>'bail|required|between:5,64|unique:users,username',                                
                                'password'=>'bail|required|min:6|max:32',
                                'phone_no'=>'bail|required|min:10|numeric',
                                'nationality'=>'bail|required|alpha_dash|min:2',
                                'auth_token'=>'bail|required|unique:users,auth_token',
                                'is_active'=>'bail|required|boolean',                                
                            ],
                            [
                                'title.in'=>'The selected title is in MR, MISS Or MRS list',
                                'gender.in'=>'The selected gender is in Male, Female list',
                            ]);
        
        if(!$validator->fails()){
            $name = $request->input('first_name').' '.$request->input('last_name');
            $request->request->set('name',$name); //set name field
            $request->request->set('password', bcrypt($request->input('password'))); //set password encrypted
            $response_code=$success_flag;      
            //return response($request->all());
            try{
                $new_member = Member::create($request->all());
                
                if($new_member!=null){
                    $member=Member::with(['country','state','city'=>function($query){ $query->select(['id','name','state_id']); }])->select(['id','title','name','first_name','last_name','gender','dob','address','country_id','state_id','city_id','email','phone_no','nationality','auth_token'])->find($new_member->id);
                    $data = array('status'=>true, 'status_code'=>$success_flag, 'message'=>"Registration successfully.", 'result'=>$member);                
                }else{
                    $response_code=$invalid_data;
                    $data = array('status'=>false,'status_code'=>$invalid_data, 'message'=>'Registration failed.');
                }
            }catch(Exception $e){
                $response_code=$failure_flag;
                $data = array('status'=>false,'status_code'=>$failure_flag, 'result'=>[], 'message'=>'Internal Error');
            }            
        }else{
            $response_code=$data_missing;
            $data = array('status'=>false,'status_code'=>$data_missing, 'result'=>[], 'message'=>$validator->messages());
        }

        return response($data,$response_code);        
        
    }
    
    /*
     * function name : login Web Service
     * Web Service for member login
     * @author :  Chandrakant Ganji
     * @access : public
     * @param : Request $request object
     * @return : JSON Response with HTTP Header
     */
    
    /**
     * @api {post} http://mfa-at-ng.com/api/members/login  Login
     * @apiName Login
     * @apiGroup Member
     * @apiDescription
     * This api for member login
     *
     * @apiVersion 1.0.0
     * @apiHeader {String} Apikey  User access token { header }
     * @apiHeader {String} username  Api access username { header }
     * @apiHeader {String} password  Api access password { header }
     * 
     * @apiSampleRequest http://mfa-at-ng.com/api/members/login
     *
     * @apiParam {String} email user email required
     * @apiParam {String} password user password required
     *
     * @apiSuccess {Boolean} status true
     * @apiSuccess {Integer} status_code Status code, 200 for success
     * @apiSuccess {Object} result Data object
     * @apiSuccess {String} message message to user
     *
     * @apiSuccessExample Success-Response:
     *      HTTP/1.1 200 Ok.
     *        {
     *           "status": true,
     *           "status_code": 200,
     *           "message": "Login successfully.",
     *           "result": {
     *             "id": 4,
     *             "title": "MR",
     *             "name": "Arjun Patil",
     *             "first_name": "Arjun",
     *             "last_name": "Patil",
     *             "gender": "Male",
     *             "dob": "1989-03-05",
     *             "address": "Nana peth",
     *             "country_id": 101,
     *             "state_id": 22,
     *             "city_id": 276,
     *             "email": "arjunpatil@gmail.com",
     *             "phone_no": "9546454649",
     *             "nationality": "Indian",
     *             "auth_token": "0XpS9fcg1Q1khpmBQb5cfItLnmBvxGUVlrzXB5zBrvnAJKG9NSi6xs6QTd2IeZrl",
     *             "country": {
     *               "id": 101,
     *               "sortname": "IN",
     *               "name": "India",
     *               "phonecode": 91
     *             },
     *             "state": {
     *               "id": 22,
     *               "name": "Maharashtra",
     *               "country_id": 101
     *             },
     *             "city": {
     *               "id": 276,
     *               "name": "Vadlapudi",
     *               "state_id": 2
     *             }
     *           }
     *         }
     *
     *
     * @apiError WrongMethod request method must be POST
     * @apiErrorExample Error-Response: Wrong method
     *     HTTP/1.1 403 Forbidden.
     *      {
     *         "status": false,
     *         "result": {},
     *         "message": "Wrong request method, must be POST"
     *      }
     */
    
    public function login(Request $request){
        
        $success_flag = config('constants.success_flag');
        $invalid_data = config('constants.invalid_data');        
        $data_missing = config('constants.data_missing');    
        $forbidden_access = config('constants.forbidden_access');        
        $response_code = config('constants.success_flag');
        
        $validator = \Validator::make($request->all(),['email'=>'required|email','password'=>'required']);
        
        if(!$validator->fails()){
            $login_status = Auth::attempt(['email' => $request->input('email'), 'password' => $request->input('password'),'is_active'=>1,'user_role_id'=>2]);
            
            if($login_status){                
                $response_code=$success_flag;      
                Member::find(Auth::user()->id)->update(['auth_token'=>str_random(64)]);
                
                $member=Member::with(['country','state','city'=>function($query){ $query->select(['id','name','state_id']); }])->select(['id','title','name','first_name','last_name','gender','dob','address','country_id','state_id','city_id','email','phone_no','nationality','auth_token'])->find(Auth::user()->id);
                
                $data = array('status'=>true, 'status_code'=>$success_flag, 'message'=>"Login successfully.", 'result'=>$member);                
            }else{                
                
                $response_code=$forbidden_access;
                $data = array('status'=>false,'status_code'=>$forbidden_access, 'message'=>'Login failed.');
            }            
        }else{
            $response_code=$data_missing;
            $data = array('status'=>false,'status_code'=>$data_missing, 'result'=>[], 'message'=>$validator->messages());
        }
        
        return response($data,$response_code);        
    }
    

    /*
     * function name : getProfile Web Service
     * Web Service for member profile information
     * @author :  Chandrakant Ganji
     * @access : public
     * @param : 
     * @return : JSON Response with HTTP Header
     */

    /**
     * @api {get} http://mfa-at-ng.com/api/members/get-profile  Profile
     * @apiName Profile
     * @apiGroup Member
     * @apiDescription
     * This api for member profile information
     *
     * @apiVersion 1.0.0
     * @apiHeader {String} Apikey  User access token { header }
     * @apiHeader {String} username  Api access username { header }
     * @apiHeader {String} password  Api access password { header }
     * @apiHeader {String} authtoken  Api access authtoken { header }
     * 
     * @apiSampleRequest http://mfa-at-ng.com/api/members/get-profile
     *
     * @apiSuccess {Boolean} status true
     * @apiSuccess {Integer} status_code Status code, 200 for success
     * @apiSuccess {Object} result Data object
     * @apiSuccess {String} message message to user
     *
     * @apiSuccessExample Success-Response:
     *      HTTP/1.1 200 Ok.
     *        {
     *           "status": true,
     *           "status_code": 200,
     *           "message": "Login successfully.",
     *           "result": {
     *                       "id": 10,
     *                       "title": "MR",
     *                       "name": "Ratan Ganure",
     *                       "first_name": "Ratan",
     *                       "last_name": "Ganure",
     *                       "gender": "Male",
     *                       "dob": "1990-05-05",
     *                       "address": "Dadar",
     *                       "country_id": 101,
     *                       "state_id": 22,
     *                       "city_id": 2707,
     *                       "email": "ratan@gmail.com",
     *                       "phone_no": "9546454813",
     *                       "nationality": "Indian",
     *                       "auth_token": "o1aACNtuPCDIAypPvaqdjfTv3nns8Xc1HIRjOoGIxzqRuqtzJhMrHyOjdq5vsyES",
     *                       "country": {
     *                         "id": 101,
     *                         "sortname": "IN",
     *                         "name": "India",
     *                         "phonecode": 91
     *                       },
     *                       "state": {
     *                         "id": 22,
     *                         "name": "Maharashtra",
     *                         "country_id": 101
     *                       },
     *                       "city": {
     *                         "id": 2707,
     *                         "name": "Mumbai",
     *                         "state_id": 22
     *                       }
     *                     }
     *         }
     *
     *
     * @apiError WrongMethod request method must be GET
     * @apiErrorExample Error-Response: Wrong method
     *     HTTP/1.1 403 Forbidden.
     *      {
     *         "status": false,
     *         "result": {},
     *         "message": "Wrong request method, must be GET"
     *      }
     */
    
    public function getProfile(Request $request){
        $success_flag = config('constants.success_flag');
        $invalid_data = config('constants.invalid_data');        
        $data_missing = config('constants.data_missing');    
        $forbidden_access = config('constants.forbidden_access');        
        $response_code = config('constants.success_flag');
        
        $member = $this->authorizeApiUser($request->header('authtoken'));
        $data = array('status'=>true, 'status_code'=>$success_flag, 'message'=>"Profile information exists.", 'result'=>$member);                
        
        return response($data,$response_code);
    }
    
    /*
     * function name : editProfile Web Service
     * Web Service for member edit personal profile information
     * @author :  Chandrakant Ganji
     * @access : public
     * @param : Request $request object
     * @return : JSON Response with HTTP Header
     */
    
    /**
     * @api {post} http://mfa-at-ng.com/api/members/edit-profile  Edit Profile
     * @apiName Edit Profile
     * @apiGroup Member
     * @apiDescription
     * This api for member edit personal profile information
     *
     * @apiVersion 1.0.0
     * @apiHeader {String} Apikey  User access token { header }
     * @apiHeader {String} username  Api access username { header }
     * @apiHeader {String} password  Api access password { header }
     * @apiHeader {String} authtoken  Api access authtoken { header }
     * 
     * @apiSampleRequest http://mfa-at-ng.com/api/members/edit-profile
     *
     * @apiParam {String} title member title is required , title in [MR, MISS Or MRS]
     * @apiParam {String} first_name member first_name is required
     * @apiParam {String} last_name member last_name is required
     * @apiParam {String} gender member gender is required value enum('Male', 'Female')
     * @apiParam {Date} dob member dob is required of format YYYY-MM-DD
     * @apiParam {String} address member address is required
     * @apiParam {Number} country_id member country_id is required
     * @apiParam {Number} state_id member state_id is required
     * @apiParam {Number} city_id member city_id is required
     * @apiParam {String} email member email is required
     * @apiParam {Number} phone_no member phone_no is required
     * @apiParam {String} nationality member nationality is required
     *
     * @apiSuccess {Boolean} status true
     * @apiSuccess {Integer} status_code Status code, 200 for success
     * @apiSuccess {Object} result Data object
     * @apiSuccess {String} message message to user
     *
     * @apiSuccessExample Success-Response:
     *      HTTP/1.1 200 Ok.
     *        {
     *           "status": true,
     *           "status_code": 200,
     *           "message": "Member profile updated successfully.",
     *           "result": {
     *                       "id": 10,
     *                       "title": "MR",
     *                       "name": "RatanEdit Ganure",
     *                       "first_name": "RatanEdit",
     *                       "last_name": "Ganure",
     *                       "gender": "Male",
     *                       "dob": "1992-10-05",
     *                       "address": "Dadar",
     *                       "country_id": 101,
     *                       "state_id": 22,
     *                       "city_id": 2707,
     *                       "email": "ratan@gmail.com",
     *                       "phone_no": "9546454813",
     *                       "nationality": "Indian",
     *                       "auth_token": "D95zT6lEzTxTlQgC2tJKTBUtLphGbE01rVDYDGSEjqa4DQs9DbwuRsVyAMVFUlpn",
     *                       "country": {
     *                         "id": 101,
     *                         "sortname": "IN",
     *                         "name": "India",
     *                         "phonecode": 91
     *                       },
     *                       "state": {
     *                         "id": 22,
     *                         "name": "Maharashtra",
     *                         "country_id": 101
     *                       },
     *                       "city": {
     *                         "id": 2707,
     *                         "name": "Mumbai",
     *                         "state_id": 22
     *                       }
     *               }
     *        }
     *
     *
     * @apiError WrongMethod request method must be POST
     * @apiErrorExample Error-Response: Wrong method
     *     HTTP/1.1 403 Forbidden.
     *      {
     *         "status": false,
     *         "result": {},
     *         "message": "Wrong request method, must be POST"
     *      }
     */
    
    public function editProfile(Request $request){
        
        $success_flag = config('constants.success_flag');
        $invalid_data = config('constants.invalid_data');        
        $data_missing = config('constants.data_missing');        
        $failure_flag = config('constants.failure_flag');        
        $forbidden_access = config('constants.forbidden_access');        
        $response_code = config('constants.success_flag');
        
        $request->request->set('user_role_id',2); //default user_role_id is 2 for member
        $request->request->set('is_active',true); //default is_active is 1 for active user
        
        $member = $this->authorizeApiUser($request->header('authtoken'));
        
        $validator = \Validator::make($request->all(),
                            [
                                'user_role_id'=>'bail|required|numeric|exists:user_roles,id',
                                'title'=>'bail|required|in:MR,MISS,MRS',
                                'first_name'=>'bail|required|alpha|between:1,128',
                                'last_name'=>'bail|required|alpha|between:1,128',
                                'gender'=>'bail|required|in:Male,Female',
                                'dob'=>'bail|required|date|date_format:Y-m-d|before:now|after:-100 years',
                                'address'=>'bail|required|min:3|max:512',
                                'country_id'=>'bail|required|numeric|exists:countries,id',
                                'state_id'=>'bail|required|numeric|exists:states,id',
                                'city_id'=>'bail|required|numeric|exists:cities,id',
                                'email'=>'bail|required|between:5,64|email|unique:users,email,'.$member->id,                                
                                'phone_no'=>'bail|required|min:10|numeric',
                                'nationality'=>'bail|required|alpha_dash|min:2',
                                'is_active'=>'bail|required|boolean',                                
                            ],
                            [
                                'title.in'=>'The selected title is in MR, MISS Or MRS list',
                                'gender.in'=>'The selected gender is in Male, Female list',
                            ]);
        
        if(!$validator->fails()){
            $name = $request->input('first_name').' '.$request->input('last_name');
            $request->request->set('name',$name); //set name field            
            $response_code=$success_flag;      
            
            try{
                $request_params = array_except($request->all(),['id','password','auth_token']);
                
                $update_member_status = Member::find($member->id)->update($request_params);
                
                if($update_member_status==true){
                    $member_updated=Member::with(['country','state','city'=>function($query){ $query->select(['id','name','state_id']); }])->select(['id','title','name','first_name','last_name','gender','dob','address','country_id','state_id','city_id','email','phone_no','nationality','auth_token'])->find($member->id);
                    $data = array('status'=>true, 'status_code'=>$success_flag, 'message'=>"Member profile updated successfully.", 'result'=>$member_updated);                
                }else{
                    $response_code=$invalid_data;
                    $data = array('status'=>false,'status_code'=>$invalid_data, 'message'=>'Member profile update failed.');
                }
            }catch(Exception $e){
                $response_code=$failure_flag;
                $data = array('status'=>false,'status_code'=>$failure_flag, 'result'=>[], 'message'=>'Internal Error');
            }            
        }else{
            $response_code=$data_missing;
            $data = array('status'=>false,'status_code'=>$data_missing, 'result'=>[], 'message'=>$validator->messages());
        }

        return response($data,$response_code);        
        
    }
    
}
