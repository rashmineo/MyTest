<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class Member extends Model
{
    use SoftDeletes;
    
    protected $table = 'users';
    
    protected $fillable = ['user_role_id','title','name','first_name','last_name','gender','dob','address','country_id','state_id','city_id','email','password','phone_no','nationality','auth_token','is_active'];
    
    protected $dates = ['deleted_at'];
    
    protected $hidden = [
        'password', 'remember_token',
    ];
    
    
    public function roles()
    {
        return $this->belongsTo('App\UserRole');
    }
    
    public function country(){
        return $this->belongsTo('App\Country');
    }
    public function state(){
        return $this->belongsTo('App\State');
    }
    public function city(){
        return $this->belongsTo('App\City');
    }    
}
