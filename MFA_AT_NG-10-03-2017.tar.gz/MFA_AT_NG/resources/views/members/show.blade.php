@extends('adminlte::page')

@section('title', 'Members')

@section('content_header')
    <h1>Member</h1>
@stop


@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Member {{ $member->id }}</div>
                    <div class="panel-body">

                        <a href="{{ url('/members') }}" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <a href="{{ url('/members/' . $member->id . '/edit') }}" title="Edit Member"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>
                        {!! Form::open([
                            'method'=>'DELETE',
                            'url' => ['members', $member->id],
                            'style' => 'display:inline'
                        ]) !!}
                            {!! Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i> Delete', array(
                                    'type' => 'submit',
                                    'class' => 'btn btn-danger btn-xs',
                                    'title' => 'Delete Member',
                                    'onclick'=>'return confirm("Confirm delete?")'
                            ))!!}
                        {!! Form::close() !!}
                        <br/>
                        <br/>

                        <div class="table-responsive">
                            <table class="table table-borderless">
                                <tbody>
                                    <tr><th> Title </th><td> {{ $member->title }} </td></tr>
                                    <tr><th> Name </th><td> {{ $member->name }} </td></tr>
                                    <tr><th> Email </th><td> {{ $member->email }} </td></tr>
                                    <tr><th> Gender </th><td> {{ $member->gender }} </td></tr>
                                    <tr><th> DOB </th><td> {{ $member->dob }} </td></tr>
                                    <tr><th> Address </th><td> {{ $member->address }} </td></tr>
                                    <tr><th> Country </th><td> {{ $member->country->name }} </td></tr>
                                    <tr><th> State </th><td> {{ $member->state->name }} </td></tr>
                                    <tr><th> City </th><td> {{ $member->city->name }} </td></tr>
                                    <tr><th> Phone No </th><td> {{ $member->phone_no }} </td></tr>
                                    <tr><th> Nationality </th><td> {{ $member->nationality }} </td></tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
