@extends('adminlte::page')

@section('title', 'Members')

@section('content_header')
    <h1>Manage Members</h1>
@stop


@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Add New Member</div>
                    <div class="panel-body">
                        <a href="{{ url('/members') }}" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />
                        
                        
                      @if ($errors->any())
                            <ul class="alert alert-danger">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                            <br/><br/>
                        @endif
                        
                        {!! Form::open(['url' => '/members', 'class' => 'form-horizontal', 'files' => true]) !!}

                        @include ('members.form',['pageType' =>'create'])
                        
                        {!! Form::close() !!}

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection