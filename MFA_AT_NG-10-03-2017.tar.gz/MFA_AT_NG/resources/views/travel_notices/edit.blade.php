@extends('adminlte::page')

@section('title','Manage Travel Notices')

@section('content_header')
<h1>Edit Travel Notices</h1>
@stop

@section('content')
<div class="container-fluid">
    <div class="panel panel-default">
        <div class="panel panel-heading"><strong>Edit Manage Travel Notices</strong></div>
        <div class="panel panel-body">
            <a href="{{ url('/travel-notices') }}" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left"></i> Back</button></a>            
            {!! Form::open(['method'=>'DELETE','url'=> ['/travel-notices/'.$travelNotice->id],'style' => 'display:inline']) !!}                                                
                {!! Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i> Delete',[
                    'type'=>'submit',
                    'class'=>'btn btn-danger btn-xs',
                    'title'=>'Delete Travel Notice',
                    'onclick' => 'return confirm("Confirm delete?")'
                ]) !!}
            {!! Form::close() !!}
            
            <br/>
            <br/>
            <div class="col-md-10">
                <div class="edit-form">
                    
                    {!! Form::model($travelNotice, [
                            'method' => 'PATCH',
                            'url' => ['/travel-notices', $travelNotice->id],
                            'class' => 'form-horizontal',
                            'files' => true
                        ]) !!}

                        @include ('travel_notices.form', ['submitButtonText' => 'Update'])

                        {!! Form::hidden('status',$travelNotice->status) !!}
                        
                        {!! Form::close() !!}
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
@endsection