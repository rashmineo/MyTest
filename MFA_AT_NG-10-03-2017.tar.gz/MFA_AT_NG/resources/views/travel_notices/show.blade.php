@extends('adminlte::page')

@section('title','Manage Travel Notices')

@section('conent_header')
<h1>Manage Travel Notices</h1>
@stop

@section('content')
<div class="container-fluid">
    <div class="panel panel-default">
        <div class="panel panel-heading"><strong>Manage Travel Notices</strong></div>
        <div class="panel panel-body">
            <a href="{{ url('/travel-notices') }}" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left"></i></button></a>
            {!! Form::open(['method'=>'DELETE','url'=> ['/travel-notices/'.$travelNotice->id],'style' => 'display:inline']) !!}                                                
                {!! Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i> Delete',[
                    'type'=>'submit',
                    'class'=>'btn btn-danger btn-xs',
                    'title'=>'Delete Travel Notice',
                    'onclick' => 'return confirm("Confirm delete?")'
                ]) !!}
            {!! Form::close() !!}
        </div>
    </div>
</div>
@endsection