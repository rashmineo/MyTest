<div class="col-md-offset-2 col-md-6">
@if ($message = Session::get('success'))
    <div class="alert alert-info">
            <p>{{ $message }}</p>
    </div>
@endif
</div>
<div class="clearfix"></div>
