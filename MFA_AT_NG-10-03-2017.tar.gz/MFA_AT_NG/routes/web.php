<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home', 'HomeController@index');

Auth::routes();

Route::get('/get-countries','LocationsController@getCountries');
Route::post('/get-countries','LocationsController@getCountries');
//Route::get('get-states','LocationsController@getStates');
Route::post('/get-states','LocationsController@getStates');
//Route::get('get-cities','LocationsController@getCities');
Route::post('/get-cities','LocationsController@getCities'); 
    
Route::resource('blogs', 'BlogsController');
Route::resource('posts', 'PostsController');

Route::resource('travel-notices', 'TravelNoticiesController');
Route::post('travel-notices/status','TravelNoticiesController@status')->name('travel-notices.status');

Route::resource('members','MembersController');
