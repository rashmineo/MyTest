<?php

namespace Tests\Browser;

use Tests\DuskTestCase;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Faker\Factory as Faker;

class LoginTest extends DuskTestCase
{
    /**
     * A Dusk test example.
     *
     * @return void
     */
    public function testExample()
    {
        $this->browse(function ($browser) {
            //$browser->visit('/')
            //        ->assertSee('Laravel');
            $browser->visit('/login')
                    ->type('email','admin@admin.com')
                    ->type('password','123456')
                    ->press('Login')
                    ->visit('/home')
                    ->waitForText('You are logged in!')
                    ->assertPathIs('/home');


            $faker = Faker::create();

            $browser->clickLink('Posts')
                    ->visit('/posts')
                    ->clickLink('Add New')
                    ->visit('/posts/create')
                    ->assertSee('Create New Post')
                    ->type('title',$faker->name)
                    ->type('content',$faker->text)
                    ->select('category', rand(0,2))
                    ->press('Create')
                    ->assertPathIs('/posts')
                    ->waitForText('Post added!')
                    ->assertSee('Posts');

            $browser->clickLink('Dashboard')
                    ->assertPathIs('/home')
                    ->clickLink('admin')
                    ->waitForLink('Logout')
                    ->clickLink('Logout'); 
        });
    }
}
